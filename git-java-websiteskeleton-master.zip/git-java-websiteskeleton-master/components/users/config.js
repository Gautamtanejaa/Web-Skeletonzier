module.exports = {
    apiUrl: '<% apiUrl %>'
};
