module.exports = {
    apiUrl: 'http://localhost:3030'
};
