module.exports = {
    dev: {
        apiUrl: 'http://localhost:3030',
        env: 'dev'
    },
    test: {
        apiUrl: 'http://localhost:3031',
        env: 'test'
    }
};