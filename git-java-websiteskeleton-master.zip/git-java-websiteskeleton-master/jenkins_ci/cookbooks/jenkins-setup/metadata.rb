name 'jenkins-setup'
version '0.0.1'

depends 'jenkins', '~> 2.2.2'