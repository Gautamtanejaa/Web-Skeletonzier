name 'ruby'
version '0.0.1'

depends 'rbenv', '~> 1.7.1'