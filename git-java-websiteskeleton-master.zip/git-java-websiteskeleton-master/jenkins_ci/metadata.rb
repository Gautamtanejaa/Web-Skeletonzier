name 'skeleton-ci'
version '0.0.1'

depends 'libffi', '~> 0.0.1'
depends 'libyaml', '~> 0.1.0'
depends 'java', '~> 1.31.0'